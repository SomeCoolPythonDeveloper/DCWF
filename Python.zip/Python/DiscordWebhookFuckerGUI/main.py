import requests
import keyboard
import time
import discord
import webbrowser
import asyncio
import os
import json
from discord import app_commands, utils
from discord.ext import commands
import datetime
import tkinter as tk
from tkinter import messagebox

class webhookFunctions():
    def __init__(self, window, menu):
        self.window = window
        self.menu = menu

    def change_webhook_name(self):
        new_name = self.webhook_name_entry.get()
        if not new_name:
            messagebox.showerror("Error", "Please enter a new name.")
            return

        try:
            webhook.name = new_name
            messagebox.showinfo("Success", "Webhook name changed successfully.")
        except Exception as e:
            messagebox.showerror("Error", str(e))

    def send_webhook_message(self):
        message = self.webhook_message_entry.get()
        if not message:
            messagebox.showerror("Error", "Please enter a message.")
            return

        try:
            webhook.send(message)
            messagebox.showinfo("Message Sent", "Message sent successfully.")
        except Exception as e:
            messagebox.showerror("Error", str(e))

    def spam_webhook_messages(self):
        message = self.webhook_spam_entry.get()
        if not message:
            messagebox.showerror("Error", "Please enter a message.")
            return

        try:
            for _ in range(10):  # Adjust the range for desired number of spam messages
                webhook.send(message)
            messagebox.showinfo("Spam Complete", "Spam messages sent successfully.")
        except Exception as e:
            messagebox.showerror("Error", str(e))
            
    def open_menu(self):

        # Submenu for webhook actions
        webhook_submenu = tk.Menu(self.menu, tearoff=0)
        self.menu.add_cascade(label="Webhook Actions", menu=webhook_submenu)
        webhook_submenu.add_command(label="Change Webhook Name", command=self.change_webhook_name)

        # Add entry and buttons for sending message and spamming messages
        self.webhook_message_label = tk.Label(self.window, text="Webhook Message:")
        self.webhook_message_label.grid(row=3, column=0, padx=5, pady=5)
        self.webhook_message_entry = tk.Entry(self.window, width=50)
        self.webhook_message_entry.grid(row=3, column=1, padx=5, pady=5)
        send_message_btn = tk.Button(self.window, text="Send Message", command=self.send_webhook_message)
        send_message_btn.grid(row=4, column=0, padx=5, pady=5)
        spam_message_label = tk.Label(self.window, text="Webhook Spam Message:")
        spam_message_label.grid(row=5, column=0, padx=5, pady=5)
        self.webhook_spam_entry = tk.Entry(self.window, width=50)
        self.webhook_spam_entry.grid(row=5, column=1, padx=5, pady=5)
        spam_message_btn = tk.Button(self.window, text="Spam Messages", command=self.spam_webhook_messages)
        spam_message_btn.grid(row=6, column=0, padx=5, pady=5)

        # Run the Tkinter event loop
        self.window.mainloop()

    # Define login_webhook method


class baseFunctions():
    #Open Discord Invite to Comms Server (JOIN IT!!!!)
    @staticmethod
    def open_discord_invite():
        webbrowser.open_new_tab("https://discord.gg/qmgTt2NKH6")

    #Clear the log file!
    @staticmethod
    def clear_logs():
        with open("latest.log", "w") as f:
            f.write("")
        messagebox.showinfo("Logs Cleared", "Logs have been cleared successfully.")

    #Open the log file
    @staticmethod
    def open_logs():
        os.system("notepad.exe latest.log")
    
    #Checks the webhook URL to make sure its valid
    @staticmethod
    def check_webhook(webhook_entry):
        url = webhook_entry.get()
        if not url:
            messagebox.showerror("Error", "Please enter a webhook URL.")
            return

        response = requests.get(url)
        if response.status_code in (200, 202, 201):
            messagebox.showinfo("Webhook Valid", "The webhook URL is valid.")
            window = tk.Tk()
            menu = tk.Menu(window)
            webhook_instance = webhookFunctions(window, menu)
            webhook_instance.open_menu()
        else:
            messagebox.showerror("Webhook Invalid", "The webhook URL is invalid.")

#Creating the TKinter GUI
# Create Tkinter window
window = tk.Tk()
window.title("DiscordWebhookFucker GUI")

# Label and entry for webhook URL
webhook_label = tk.Label(window, text="Webhook URL:")
webhook_label.grid(row=0, column=0, padx=5, pady=5)
webhook_entry = tk.Entry(window, width=50)
webhook_entry.grid(row=0, column=1, padx=5, pady=5)

# Buttons for Discord invite, Clear Logs, Open Logs, and Check Webhook
discord_invite_btn = tk.Button(window, text="Open Discord Invite", command=baseFunctions.open_discord_invite)
discord_invite_btn.grid(row=1, column=0, padx=5, pady=5)
clear_logs_btn = tk.Button(window, text="Clear Logs", command=baseFunctions.clear_logs)
clear_logs_btn.grid(row=1, column=1, padx=5, pady=5)
open_logs_btn = tk.Button(window, text="Open Logs", command=baseFunctions.open_logs)
open_logs_btn.grid(row=2, column=0, padx=5, pady=5)
check_webhook_btn = tk.Button(window, text="Check Webhook", command=lambda: baseFunctions.check_webhook(webhook_entry))
check_webhook_btn.grid(row=2, column=1, padx=5, pady=5)

# Run the Tkinter event loop
window.mainloop()
